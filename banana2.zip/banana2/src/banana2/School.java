package banana2;

public class School {

	public static void main(String[] args) {
		Teacher ccs =new Teacher();
		ccs.name="張春生";
		ccs.weight=97.8;
		
		ccs.減肥(5);
		ccs.教書();
		ccs.教書();
		ccs.教書();
		ccs.量體重();

	}

}

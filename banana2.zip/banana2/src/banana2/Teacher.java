package banana2;

public class Teacher {
	String name;//屬性
	double weight;
	
	public void 減肥(double 減掉的重量) {
		weight=weight-減掉的重量;
	}
	
	public void 教書() {
		System.out.println("老師上了一門課");
		減肥(-0.01);
	}
	
	public void 量體重() {
		System.out.println(weight+"公斤");
	}
	

}
